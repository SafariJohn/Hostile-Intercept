package commands;

import com.fs.starfarer.api.Global;
import org.lazywizard.console.BaseCommand;
import org.lazywizard.console.CommonStrings;
import org.lazywizard.console.Console;
import static ids.HostileIntercept_Settings.*;

/**
 * Author: SafariJohn
 *
 * hi_interceptalarm
 */
public class HostileIntercept_InterceptAlarmCommand implements BaseCommand {

    @Override
    public CommandResult runCommand(String args, CommandContext context) {
        if (!context.isInCampaign()) {
            Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY);
            return CommandResult.WRONG_CONTEXT;
        }

        args = args.toLowerCase().trim();

        if (!args.isEmpty()) {
            return CommandResult.BAD_SYNTAX;
        }

        setAlarm(!isFeatureEnabled(INTERCEPT_ALARM_KEY));

        return CommandResult.SUCCESS;
    }

    private void setAlarm(boolean enabled) {
        Global.getSector().getMemoryWithoutUpdate().set("$" + INTERCEPT_ALARM_KEY, enabled);
        if (enabled) Console.showMessage("Intercept alarm enabled");
        else Console.showMessage("Intercept alarm disabled");
    }
}