package scripts;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SectorEntityToken.VisibilityLevel;
import com.fs.starfarer.api.campaign.ai.FleetAIFlags;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.loading.CampaignPingSpec;
import com.fs.starfarer.api.util.Misc;
import static ids.HostileIntercept_Settings.*;
import java.awt.Color;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import static scripts.HostileIntercept_ModPlugin.BOOLEAN_CHECK_INTERVAL;

/**
 * Author: SafariJohn
 */
public class HostileIntercept_JumpPointPause implements EveryFrameScript {

	public static final float INTERVAL = 0.1f;
	public static final float PAUSE_DELAY = 0.3f;

    private boolean autopause;
    private boolean threatenedOnly;
    private boolean withSound;
    private boolean wasInHyper;
    private String soundId;
    private String threatsSoundId;

    private float interval = 0;
    private float booleansInterval = 0;
    private boolean pausing = false;

    public HostileIntercept_JumpPointPause() {
        autopause = isFeatureEnabled(JUMP_PAUSE_KEY);
        threatenedOnly = isFeatureEnabled(JUMP_PAUSE_THREATS_KEY);
        withSound = isFeatureEnabled(JUMP_PAUSE_ALARM_KEY);
        wasInHyper = Global.getSector().getPlayerFleet().isInHyperspace();
        soundId = Global.getSettings().getString(ALARM_SOUND_KEY);
        threatsSoundId = Global.getSettings().getString(INTERCEPT_SOUND_KEY);
    }



    @Override
    public void advance(float amount) {
        if (Global.getSector().isPaused()) {
            pausing = false;
            return;
        }

        interval += amount;
        booleansInterval += amount;

        if (booleansInterval >= BOOLEAN_CHECK_INTERVAL) {
            booleansInterval -= BOOLEAN_CHECK_INTERVAL;
            autopause = isFeatureEnabled(JUMP_PAUSE_KEY);
            threatenedOnly = isFeatureEnabled(JUMP_PAUSE_THREATS_KEY);
            withSound = isFeatureEnabled(JUMP_PAUSE_ALARM_KEY);
        }

        if (!autopause) return;


        SectorEntityToken target = Global.getSector().getUIData().getCourseTarget();
        boolean reachingTarget = target == Global.getSector().getPlayerFleet().getInteractionTarget();
        boolean jumpingNow = reachingTarget && (target instanceof JumpPointAPI);
        if (target != null && !jumpingNow) return;

        if (pausing) {
            if (interval > PAUSE_DELAY) {
                interval -= PAUSE_DELAY;

                if (autopause) Global.getSector().setPaused(true);

                pausing = false;
            }

            return;
        }

        if (interval < INTERVAL) return;

        interval -= INTERVAL;

        boolean inTransition = Global.getSector().getPlayerFleet().isInHyperspaceTransition();
        boolean isInHyper = Global.getSector().getPlayerFleet().isInHyperspace();

        if (inTransition && wasInHyper != isInHyper) {
            wasInHyper = isInHyper;

            Set<SectorEntityToken> threats = getThreats();

            if (threatenedOnly && threats.isEmpty()) return;

            if (!threats.isEmpty()) {
                String msg = "Potential threats detected";
                if (threats.size() == 1) msg = "Potential threat detected";

                Global.getSector().getCampaignUI()
                        .getMessageDisplay().addMessage(msg);
            }

            pause(threats);
        }
    }

    private Set<SectorEntityToken> getThreats() {
        Set<SectorEntityToken> threats = new HashSet<>();

        // Check all entities
        List<SectorEntityToken> entities = Global.getSector()
                    .getPlayerFleet().getContainingLocation().getAllEntities();

        for (SectorEntityToken entity : entities) {
            // Ignore planets and stuff
            if (entity instanceof PlanetAPI) continue;

            // Must be visible
            if (entity.getVisibilityLevelToPlayerFleet() == SectorEntityToken.VisibilityLevel.NONE) continue;

            // Ignore transient objects (cargo pods and battlefield debris)
            if (entity.getFaction().isNeutralFaction() && !entity.isDiscoverable()) continue;

            // Pause for sensor contacts and unknown fleets
            VisibilityLevel vis = entity.getVisibilityLevelToPlayerFleet();
            if (vis == VisibilityLevel.COMPOSITION_DETAILS
                        || vis == VisibilityLevel.SENSOR_CONTACT) {
                threats.add(entity);
                continue;
            }

            // Pause for intercepting fleets
            // Must be a fleet
            if (!(entity instanceof CampaignFleetAPI)) continue;
            // Must be visible
            if (vis == VisibilityLevel.SENSOR_CONTACT
                        || vis == VisibilityLevel.NONE) continue;

            // Must be hostile or targeting the player
            boolean isHostile = entity.getFaction().isHostileTo(Factions.PLAYER)
                        || entity.getMemoryWithoutUpdate().getBoolean(MemFlags.MEMORY_KEY_MAKE_HOSTILE);
            SectorEntityToken target = (SectorEntityToken) entity
                        .getMemoryWithoutUpdate().get(FleetAIFlags.PURSUIT_TARGET);
            if (isHostile || target == Global.getSector().getPlayerFleet()) {
                threats.add(entity);
                continue;
            }
        }

        return threats;
    }

    private void pause(Set<SectorEntityToken> threats) {
        pausing = true;

        if (withSound) {
            String sound = soundId;
            if (threats.isEmpty()) sound = threatsSoundId;
            try { // Play nothing if the soundId is invalid
                Global.getSoundPlayer().playUISound(sound, 1f, 1f);
            } catch (RuntimeException ex) {}
        }

        for (SectorEntityToken threat : threats) {
            ping(threat);
        }
    }

    private void ping(SectorEntityToken entity) {
        Color color = Misc.getHighlightColor();
        float range = entity.getRadius();

        CampaignPingSpec custom = new CampaignPingSpec();
        custom.setColor(color);
        custom.setUseFactionColor(false);
        custom.setWidth(Math.max(range / 5, 10));
        custom.setMinRange(range / 2);
        custom.setRange(range * 10);
        custom.setDuration(PAUSE_DELAY * 3);
        custom.setAlphaMult(1f);
        custom.setInFraction(0.5f);
        custom.setNum(2);
        custom.setInvert(true);

        Global.getSector().addPing(entity, custom);
    }


    public boolean isDone() {
        return false;
    }
    public boolean runWhilePaused() {
        return false;
    }
}
