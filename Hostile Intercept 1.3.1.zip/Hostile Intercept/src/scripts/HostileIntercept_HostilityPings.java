package scripts;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken.VisibilityLevel;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.loading.CampaignPingSpec;
import java.awt.Color;
import java.util.List;

/**
 * Author: SafariJohn
 */
public class HostileIntercept_HostilityPings implements EveryFrameScript {
    public static final Color HOSTILE_COLOR = new Color(255,0,0,255);
	public static final float INTERVAL = .2f;

    private float interval = 0;

    @Override
    public void advance(float amount) {
        if (Global.getSector().isPaused()) return;

        interval += amount;
        if (interval < INTERVAL) return;

        interval -= INTERVAL;

        List<CampaignFleetAPI> fleets = Global.getSector().getPlayerFleet().getContainingLocation().getFleets();

        for (CampaignFleetAPI fleet : fleets) {
            VisibilityLevel vis = fleet.getVisibilityLevelToPlayerFleet();
            if (vis != VisibilityLevel.COMPOSITION_AND_FACTION_DETAILS) continue;

            boolean isHostile = fleet.getMemoryWithoutUpdate().contains(MemFlags.MEMORY_KEY_MAKE_HOSTILE);
            isHostile |= fleet.getFaction().isHostileTo(Factions.PLAYER);

            if (!isHostile) continue;

            Color color = HOSTILE_COLOR;
            float range = fleet.getRadius();

			CampaignPingSpec custom = new CampaignPingSpec();
            custom.setColor(color);
			custom.setUseFactionColor(false);
			custom.setWidth(Math.max(range / 5, 10));
			custom.setMinRange(range / 2);
			custom.setRange(range);
			custom.setDuration(.6f);
			custom.setAlphaMult(1f);
			custom.setInFraction(0.5f);
			custom.setNum(1);
//            custom.setInvert(true);

			Global.getSector().addPing(fleet, custom);
        }
    }

    public boolean isDone() {
        return false;
    }
    public boolean runWhilePaused() {
        return false;
    }
}
