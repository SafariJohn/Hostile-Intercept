package scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.util.Misc;
import static ids.HostileIntercept_Settings.*;

/**
 * Author: SafariJohn
 */
public class HostileIntercept_ModPlugin extends BaseModPlugin {

    public static final float BOOLEAN_CHECK_INTERVAL = 10f; // Seconds

    private static final String SYNC_KEY = "$hostileIntercept_syncKey";
    private String syncId;

    @Override
    public void onApplicationLoad() throws Exception {
        syncId = Misc.genUID();
    }

    @Override
    public void onGameLoad(boolean newGame) {
        syncWithSettings();

        if (!Global.getSector().hasScript(HostileIntercept_HostilityPings.class)) {
            Global.getSector().addTransientScript(new HostileIntercept_HostilityPings());
        }
        if (!Global.getSector().hasScript(HostileIntercept_InterceptPings.class)) {
            Global.getSector().addTransientScript(new HostileIntercept_InterceptPings());
        }
        if (!Global.getSector().hasScript(HostileIntercept_JumpPointPause.class)) {
            Global.getSector().addTransientScript(new HostileIntercept_JumpPointPause());
        }

        boolean autopause = isFeatureEnabled(AUTOPAUSE_KEY);
        boolean withSound = isFeatureEnabled(ALARM_KEY);

        if (!Global.getSector().hasScript(HostileIntercept_Autopause.class)) {
//                    && (autopause || withSound)) {
            Global.getSector().addTransientScript(new HostileIntercept_Autopause(autopause, withSound));
        }
    }

    private void syncWithSettings() {
        MemoryAPI memory = Global.getSector().getMemoryWithoutUpdate();

        if (memory.contains(SYNC_KEY) && syncId.equals(memory.getString(SYNC_KEY))) return;

        memory.set(SYNC_KEY, syncId);

        memory.set("$" + ALARM_KEY, Global.getSettings().getBoolean(ALARM_KEY));
        memory.set("$" + AUTOPAUSE_KEY, Global.getSettings().getBoolean(AUTOPAUSE_KEY));
        memory.set("$" + INTERCEPT_ALARM_KEY, Global.getSettings().getBoolean(INTERCEPT_ALARM_KEY));

        boolean jumpPause = Global.getSettings().getBoolean(JUMP_PAUSE_KEY);
        boolean ifThreatened = Global.getSettings().getBoolean(JUMP_PAUSE_THREATS_KEY);
        boolean jumpAlarm = Global.getSettings().getBoolean(JUMP_PAUSE_ALARM_KEY);
        if (!jumpPause) {
            ifThreatened = false;
            jumpAlarm = false;
        }

        memory.set("$" + JUMP_PAUSE_KEY, jumpPause);
        memory.set("$" + JUMP_PAUSE_THREATS_KEY, ifThreatened);
        memory.set("$" + JUMP_PAUSE_ALARM_KEY, jumpAlarm);
    }
}
